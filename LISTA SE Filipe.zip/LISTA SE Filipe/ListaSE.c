
#include "ListaSE.h"
#include <stdlib.h>


void criaLista( ListaSE *lt){
    lt->inicio = NULL;
}
int incluiAntes(ListaSE *lt,Contato c){
    Nodo *pNodo;

    pNodo=(Nodo *) malloc (sizeof(Nodo));

    if(pNodo == NULL)
        return faltou_memoria;
    else {
        pNodo->info = c;
        pNodo->prox = lt->inicio;
        lt->inicio=pNodo;
        return sucesso;
    }
}
void exibeLista(ListaSE lt){
    Nodo *pAux;
    pAux=lt.inicio;

    while(pAux != NULL){
        printf("%s\n",pAux->info.nome);
        printf("%d\n",pAux->info.num);
        pAux = pAux->prox;
   }
}
