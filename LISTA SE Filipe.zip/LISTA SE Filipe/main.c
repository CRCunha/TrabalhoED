#include <stdio.h>
#include <stdlib.h>
#include "ListaSE.h"

int main()
{
    ListaSE lista;
    Contato contato;

    criaLista(&lista);

    contato.nome[10]="Filipe";
    contato.num=91919191;

    incluiAntes(&lista,contato);
    exibeLista(lista);


    return 0;
}
