#ifndef ListaSE_H
#define Lista_H


#define sucesso 0
#define lista_vazia 1
#define faltou_memoria 2
#define contato_inexistente 3

typedef struct{
    int num;
    char nome[10];
}Contato;

typedef struct nodo Nodo;

struct nodo{
    Contato info;
    Nodo *prox;
};
typedef struct{
    Nodo *inicio;
}ListaSE;

void criaLista(ListaSE *lt);
int incluiAntes(ListaSE *lt,Contato c);
void exibeLista(ListaSE lt);



#endif // ListaSE_H
